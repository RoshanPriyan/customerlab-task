from rest_framework import serializers
from .models import *


class DestinationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Account
        fields = ['account_id', 'url','http_method','headers']