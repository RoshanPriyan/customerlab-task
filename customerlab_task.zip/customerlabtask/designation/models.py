from django.db import models
from api.models import *

class Destination(models.Model):
    account_id = models.ForeignKey(Account, on_delete=models.CASCADE, related_name='destinations')
    url = models.URLField()
    http_method = models.CharField(max_length=10)
    headers = models.TextField()
