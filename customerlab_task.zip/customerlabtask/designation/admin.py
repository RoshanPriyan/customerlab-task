from django.contrib import admin
from  designation.models import *
# Register your models here.
admin.site.register(Destination)