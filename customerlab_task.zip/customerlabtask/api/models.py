from django.db import models

# Create your models here.
class Account(models.Model):
    email = models.EmailField(unique=True)
    account_id = models.CharField(unique=True, max_length=255,primary_key=True)
    account_name = models.CharField(max_length=255)
    app_secret_token = models.CharField(max_length=255)
    website = models.URLField(blank=True)
    
    
