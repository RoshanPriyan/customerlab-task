from django.shortcuts import render

# Create your views here.
from rest_framework import views, status
from rest_framework.response import Response
from api.models import Account
from designation.models import Destination
from .serializers import DataHandlerSerializer
import requests

class DataHandlerView(views.APIView):
    def post(self, request):
        app_secret_token = request.headers.get('CL-X-TOKEN')
        if not app_secret_token:
            return Response({"error": "Unauthenticated"}, status=status.HTTP_401_UNAUTHORIZED)

        try:
            account = Account.objects.get(app_secret_token=app_secret_token)
        except Account.DoesNotExist:
            return Response({"error": "Invalid app secret token"}, status=status.HTTP_401_UNAUTHORIZED)

        serializer = DataHandlerSerializer(data=request.data)
        if not serializer.is_valid():
            return Response({"error": "Invalid data"}, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        destinations = Destination.objects.filter(account=account)

        for destination in destinations:
            headers = destination.headers
            headers['Content-Type'] = 'application/json'
            headers['Accept'] = '*'

            if destination.http_method == 'GET':
                params = data
                response = requests.get(destination.url, params=params, headers=headers)
            elif destination.http_method in ('POST', 'PUT'):
                response = requests.request(destination.http_method, destination.url, json=data, headers=headers)
            else:
                # Handle unsupported HTTP methods if needed
                continue

            # Process the response if necessary

        return Response({"success": True})
